function [LCL,UCL]=FCR_CI(x,s2,q,df,IsEstiVar)
% This function calculate the empirical Bayesian FCR controlling intervals.
% The output is the lower confidence limit and upper confidence limit. The
% input is x, s2, q(=0.05), df, and IsEstiVar
% 
% x, s2 could be either a column vector or a matrix. df should also be a
% matrix with the same dimension as x and s2.
%
% If IsEstiVar is true, then s2 is an unbiased estimator of \sigma_i^2. We
% will apply Exponential Lindley James Stein's estimator to obtain the
% variance shrinkage estimator
%
% If IsEstiVar is False, then we assume known variance \sigma_i^2=s_i^2.


p=size(x,1);


muHat=mean(x,1);
muHat=nncopy(muHat,p,1);

if IsEstiVar
    m=psi(0,df/2)+log(2)-log(df);
    sigmaKSq=psi(1,df/2);

    [sigmaSqHat,MvHat]=LJS(log(s2)-m,sigmaKSq);
    sigmaSqHat=exp(sigmaSqHat);
else
    sigmaSqHat=s2;
end

z_crit=norminv(1-q/2);
num=2*z_crit^2*mean(sigmaSqHat,1)+sqrt(4*z_crit^4*mean(sigmaSqHat,1).^2+2*z_crit^2*mean(sigmaSqHat.^2,1)*(p-2*z_crit^2));
tau0Sq=num/(p-2*z_crit^2);

tauSqHat=max(mean((x-muHat).^2-s2,1),tau0Sq);
tauSqHat=nncopy(tauSqHat,p,1);


MHat=tauSqHat./(tauSqHat+sigmaSqHat);


center=MHat.*x+(1-MHat).*muHat;

leng=sqrt(tinv(1-q/2,df)^2-log(MHat)).*sqrt(MHat.*sigmaSqHat);

LCL=center-leng;
UCL=center+leng;
