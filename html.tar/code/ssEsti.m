function [thetaHat]=ss_esti(X,sSq,df)
% This function calculate the double Shrinkage Estimator 
%
% The input are the observation X, the S^2, and the degrees of freedom
% The output is the estimators of all the parameters.
%
% The input can be a matrix X_{ij}, where i=1,2,...,p, j=1,2,..., number of
% replicates.
% 
% If your matrix is in the other order, please transform it first.
%
% The Degrees of Freedom can be a constant or an array.
%
%
% Example:
%           x=normrnd(0,1,10,1)
%           s2=chi2rnd(5,10,1)
%           df=nncopy(2,10,1)
%           theta=ss_esti(x,s2,df)

p=size(X,1);
numSim=size(X,2);
if p==1
    X=X';
    sSq=sSq';
    df=df';
end

p=size(X,1);

muK=(psi(0,df/2)+log(2)-log(df));
sigmaK=sqrt(psi(1,df/2));

[sigmaSqHat,MvHat]=variance_LJS(sSq,muK,sigmaK);

muHat=sum(X./sigmaSqHat./(nncopy(sum(1./sigmaSqHat,1),p,1)),1);
muHat=nncopy(muHat,p,1);
tauSqHat=max(mean((X-muHat).^2-sSq),0);
tauSqHat=nncopy(tauSqHat,p,1);

MiEB=tauSqHat./(tauSqHat+sigmaSqHat);

thetaHat=MiEB.*X+(1-MiEB).*muHat;
