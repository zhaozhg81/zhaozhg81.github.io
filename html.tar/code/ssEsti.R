ssEsti <- function(X,sSq,df){
  p <- length(X)
  muK <- (digamma(df/2)-log(df/2))
  sigmaK <- sqrt(trigamma(df/2))

  sigmaSqHat <- varianceLJS(sSq,muK,sigmaK)

  muHat <- sum((X/sigmaSqHat)/sum((1/sigmaSqHat)))
  tauHatSq <- mean((X-muHat)^2-sSq)
  tauHatSq <- tauHatSq*(tauHatSq>0)+0*(tauHatSq<=0)
  Mi <- tauHatSq/(tauHatSq+sigmaSqHat)

  theta <- Mi*X+(1-Mi)*muHat
  theta
}

varianceLJS <- function(sSq,muK,sigmaK){
  p <- length(sSq)
  muvHat <- mean(log(sSq)-muK)
  tauvHat <- mean((log(sSq)-muK)^2-sigmaK^2)-muvHat^2;
  tauvHat <- tauvHat*(tauvHat>0)+0*(tauvHat<=0)
  MvHat <- tauvHat/(tauvHat+sigmaK^2)
  sigmaSqHat <- exp(MvHat*(log(sSq)-muK)+(1-MvHat)*muvHat)
}
