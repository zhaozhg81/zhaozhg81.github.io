%%
function [out,shkf]=LJS(X,var)


%% This function calculate the Lindley-James-Stein's estimator

%This is JS shrinking toward mean.  
%X|Q~N(Q,var)

%The input can be a matrix or column vector

p=size(X,1);%the row is the dimentions of the data


if size(X,2)==1  % if it is a vector

   m=mean(X);% the sample mean( mu_v)
   out=(X-m)'*(X-m);
   shkf=1-(p-3)*var/out;%the shrinkign factor(M_v)
   shkf=max(shkf,0);
   out=m+shkf*(X-m);


else 
  m=mean(X,1);
  mm=repmat(m,p,1);
  out=sum((X-mm).^2,1);
  shkf=1-(p-3)*var./out;
  shkf=max(shkf,0);
  out=mm+repmat(shkf,p,1).*(X-mm);
 end;


%%


