function [sigmaSqHat,MvHat]=variance_LJS(sSq,muK,sigmaK)

p=size(sSq,1);
muvHat=mean(log(sSq)-muK,1);
muvHat=nncopy(muvHat,p,1);

tauvHat=mean((log(sSq)-muK).^2-sigmaK.^2-muvHat.^2,1);
tauvHat=max(tauvHat,0);
tauvHat=nncopy(tauvHat,p,1);

MvHat=tauvHat./(tauvHat+sigmaK.^2);
sigmaSqHat=exp(MvHat.*(log(sSq)-muK)+(1-MvHat).*muvHat);
