FCRCI <- function(x,s2,q,df,IsEstiVar)
  {
      p <- length(x)
      muHat <- mean(x)

      if(IsEstiVar=='true')
        {
          muK <- (digamma(df/2)-log(df/2))
          sigmaK <- sqrt(trigamma(df/2))

          sigmaSqHat <- varianceLJS(s2,muK,sigmaK)
        }
      if (IsEstiVar=='false')
        {
          sigmaSqHat <- s2;
        }

      zCrit <- qnorm(1-q/2);
      num <- 2*zCrit^2*mean(sigmaSqHat)+sqrt(4*zCrit^4*mean(sigmaSqHat)^2+2*zCrit^2*mean(sigmaSqHat^2)*(p-2*zCrit^2));
      tau0Sq <- num/(p-2*zCrit^2);
      
      tauSqHat <- max(mean((x-muHat)^2-s2),tau0Sq);

      MHat <- tauSqHat/(tauSqHat+sigmaSqHat);
      center <- MHat*x+(1-MHat)*muHat;
      leng <- sqrt(qt(1-q/2,df)^2-log(MHat))*sqrt(MHat*sigmaSqHat);

      LCL <- center-leng;
      UCL <- center+leng;

      list(LCL=LCL,UCL=UCL)

  }


varianceLJS <- function(sSq,muK,sigmaK){
  p <- length(sSq)
  muvHat <- mean(log(sSq)-muK)
  tauvHat <- mean((log(sSq)-muK)^2-sigmaK^2)-muvHat^2;
  tauvHat <- tauvHat*(tauvHat>0)+0*(tauvHat<=0)
  MvHat <- tauvHat/(tauvHat+sigmaK^2)
  sigmaSqHat <- exp(MvHat*(log(sSq)-muK)+(1-MvHat)*muvHat)
}
